System.register([],function(e,n){"use strict";return{execute:function(){e("_",""+new URL("../icons/hint-confirm-icon.svg",n.meta.url).href)}}});
